namespace veganDoenerSimulator {
    export enum IngredientNames {
        Zwiebel = "zwiebel",
        Salat = "salat",
        Fleisch = "fleisch",
        Sauce = "sauce",
        Brot = "brot",
        Fladenbrot = "fladenbrot",
        Tomate = "tomaten"
    }
}