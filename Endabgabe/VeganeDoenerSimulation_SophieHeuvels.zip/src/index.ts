namespace veganDoenerSimulator {
    document.addEventListener('DOMContentLoaded', function() {
        //create game entrypoint
        new Game();
    });
}