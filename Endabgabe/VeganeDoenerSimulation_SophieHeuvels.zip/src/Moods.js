"use strict";
var YufkaSimulator;
(function (YufkaSimulator) {
    let Moods;
    (function (Moods) {
        Moods["Hungry"] = "hungry";
        Moods["Happy"] = "happy";
        Moods["Angry"] = "angry";
        Moods["AlotAngry"] = "alotangry";
        Moods["Tired"] = "tired";
        Moods["Chef"] = "chef";
    })(Moods = YufkaSimulator.Moods || (YufkaSimulator.Moods = {}));
})(YufkaSimulator || (YufkaSimulator = {}));
//# sourceMappingURL=Moods.js.map