"use strict";
var veganDoenerSimulator;
(function (veganDoenerSimulator) {
    let Moods;
    (function (Moods) {
        Moods["Hungry"] = "hungry";
        Moods["Happy"] = "happy";
        Moods["Angry"] = "angry";
        Moods["AlotAngry"] = "alotangry";
        Moods["Tired"] = "tired";
        Moods["Chef"] = "chef";
    })(Moods = veganDoenerSimulator.Moods || (veganDoenerSimulator.Moods = {}));
})(veganDoenerSimulator || (veganDoenerSimulator = {}));
//# sourceMappingURL=Moods.js.map