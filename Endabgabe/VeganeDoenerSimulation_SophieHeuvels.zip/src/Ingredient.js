"use strict";
var YufkaSimulator;
(function (YufkaSimulator) {
    class Ingredient {
        constructor(itemName) {
            this.name = itemName;
        }
    }
    YufkaSimulator.Ingredient = Ingredient;
})(YufkaSimulator || (YufkaSimulator = {}));
//# sourceMappingURL=Ingredient.js.map