"use strict";
var veganDoenerSimulator;
(function (veganDoenerSimulator) {
    class Ingredient {
        constructor(itemName) {
            this.name = itemName;
        }
    }
    veganDoenerSimulator.Ingredient = Ingredient;
})(veganDoenerSimulator || (veganDoenerSimulator = {}));
//# sourceMappingURL=Ingredient.js.map