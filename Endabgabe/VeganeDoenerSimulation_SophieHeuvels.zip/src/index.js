"use strict";
var YufkaSimulator;
(function (YufkaSimulator) {
    document.addEventListener('DOMContentLoaded', function () {
        //create game entrypoint
        new YufkaSimulator.Game();
    });
})(YufkaSimulator || (YufkaSimulator = {}));
//# sourceMappingURL=index.js.map