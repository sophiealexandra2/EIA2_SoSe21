"use strict";
var veganDoenerSimulator;
(function (veganDoenerSimulator) {
    document.addEventListener("DOMContentLoaded", function () {
        //create game entrypoint
        new veganDoenerSimulator.Game();
    });
})(veganDoenerSimulator || (veganDoenerSimulator = {}));
//# sourceMappingURL=index.js.map