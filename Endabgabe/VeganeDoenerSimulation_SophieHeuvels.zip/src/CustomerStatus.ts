namespace veganDoenerSimulator {
    export enum CustomerStatus {
        ComingIn = "comingin",
        Waiting = "waiting",
        Leaving = "leaving"
    }
}