namespace veganDoenerSimulator {
    export enum FoodNames {
        Yufka = "yufka",
        Lahmacun = "lahmacun",
        Doener = "doener"
    }
}