namespace veganDoenerSimulator {
    export enum Moods {
        Hungry = "hungry",
        Happy = "happy",
        Angry = "angry",
        AlotAngry = "alotangry",
        Tired = "tired",
        Chef = "chef"
    }
}
