"use strict";
var YufkaSimulator;
(function (YufkaSimulator) {
    let FoodNames;
    (function (FoodNames) {
        FoodNames["Yufka"] = "yufka";
        FoodNames["Lahmacun"] = "lahmacun";
        FoodNames["Doener"] = "doener";
    })(FoodNames = YufkaSimulator.FoodNames || (YufkaSimulator.FoodNames = {}));
})(YufkaSimulator || (YufkaSimulator = {}));
//# sourceMappingURL=FoodNames.js.map