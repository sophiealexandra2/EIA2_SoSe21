"use strict";
var veganDoenerSimulator;
(function (veganDoenerSimulator) {
    let FoodNames;
    (function (FoodNames) {
        FoodNames["Yufka"] = "yufka";
        FoodNames["Lahmacun"] = "lahmacun";
        FoodNames["Doener"] = "doener";
    })(FoodNames = veganDoenerSimulator.FoodNames || (veganDoenerSimulator.FoodNames = {}));
})(veganDoenerSimulator || (veganDoenerSimulator = {}));
//# sourceMappingURL=FoodNames.js.map