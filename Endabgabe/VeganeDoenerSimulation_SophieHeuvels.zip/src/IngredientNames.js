"use strict";
var veganDoenerSimulator;
(function (veganDoenerSimulator) {
    let IngredientNames;
    (function (IngredientNames) {
        IngredientNames["Zwiebel"] = "zwiebel";
        IngredientNames["Salat"] = "salat";
        IngredientNames["Fleisch"] = "fleisch";
        IngredientNames["Sauce"] = "sauce";
        IngredientNames["Brot"] = "brot";
        IngredientNames["Fladenbrot"] = "fladenbrot";
        IngredientNames["Tomate"] = "tomaten";
    })(IngredientNames = veganDoenerSimulator.IngredientNames || (veganDoenerSimulator.IngredientNames = {}));
})(veganDoenerSimulator || (veganDoenerSimulator = {}));
//# sourceMappingURL=IngredientNames.js.map