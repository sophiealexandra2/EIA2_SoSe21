"use strict";
var YufkaSimulator;
(function (YufkaSimulator) {
    let IngredientNames;
    (function (IngredientNames) {
        IngredientNames["Zwiebel"] = "zwiebel";
        IngredientNames["Salat"] = "salat";
        IngredientNames["Fleisch"] = "fleisch";
        IngredientNames["Sauce"] = "sauce";
        IngredientNames["Brot"] = "brot";
        IngredientNames["Fladenbrot"] = "fladenbrot";
        IngredientNames["Tomate"] = "tomaten";
    })(IngredientNames = YufkaSimulator.IngredientNames || (YufkaSimulator.IngredientNames = {}));
})(YufkaSimulator || (YufkaSimulator = {}));
//# sourceMappingURL=IngredientNames.js.map